const courses = [
    {
        id: 1,
        name: "Web Development",
        instructor: "Dr. John Smith",
        description: "Master HTML, CSS, and JavaScript.",
        duration: "8 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 2,
        name: "Python for Beginners",
        instructor: "Prof. Emily Johnson",
        description: "Learn Python from scratch.",
        duration: "6 weeks",
        image: "images/course2.jpg"
    },
    {
        id: 3,
        name: "Data Science with Python",
        instructor: "Dr. Robert Brown",
        description: "Explore data analysis and machine learning.",
        duration: "10 weeks",
        image: "images/course3.jpg"
    },
    {
        id: 4,
        name: "Cybersecurity Fundamentals",
        instructor: "Mr. Alan White",
        description: "Protect systems and data from cyber threats.",
        duration: "12 weeks",
        image: "images/course4.jpg"
    },
    {
        id: 5,
        name: "UI/UX Design",
        instructor: "Ms. Laura Adams",
        description: "Design user-friendly and engaging interfaces.",
        duration: "8 weeks",
        image: "images/course5.jpg"
    },
    {
        id: 6,
        name: "Mobile App Development",
        instructor: "Dr. Michael Green",
        description: "Develop Android and iOS applications.",
        duration: "10 weeks",
        image: "images/course6.jpg"
    },
    {
        id: 7,
        name: "Digital Marketing",
        instructor: "Mrs. Sophia Martinez",
        description: "Learn SEO, social media, and email marketing.",
        duration: "7 weeks",
        image: "images/course7.jpg"
    },
    {
        id: 8,
        name: "Artificial Intelligence",
        instructor: "Dr. Kevin Harris",
        description: "Understand neural networks and deep learning.",
        duration: "12 weeks",
        image: "images/course8.jpg"
    },
    {
        id: 9,
        name: "Game Development",
        instructor: "Mr. Daniel Clark",
        description: "Create video games with Unity and Unreal Engine.",
        duration: "10 weeks",
        image: "images/course9.jpg"
    },
    {
        id: 10,
        name: "Blockchain and Cryptocurrency",
        instructor: "Prof. Olivia Wilson",
        description: "Explore decentralized finance and smart contracts.",
        duration: "8 weeks",
        image: "images/course10.jpg"
    }
];

export default courses;
