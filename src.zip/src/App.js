import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Homepage from './HomePage';
import CoursesPage from './CoursesPage';
import './App.css';

function App() {
  const [enrolledCourses, setEnrolledCourses] = useState([]);

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('enrolledCourses');
    if (saved) {
      setEnrolledCourses(JSON.parse(saved));
    }
  }, []);

  // Save to localStorage when enrolledCourses changes
  useEffect(() => {
    localStorage.setItem('enrolledCourses', JSON.stringify(enrolledCourses));
  }, [enrolledCourses]);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Homepage enrolledCourses={enrolledCourses} />} />
        <Route 
          path="/courses" 
          element={
            <CoursesPage 
              enrolledCourses={enrolledCourses}
              setEnrolledCourses={setEnrolledCourses}
            />
          } 
        />
      </Routes>
    </Router>
  );
}

export default App;