import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import CourseCatalog from './components/CourseCatalog';
import EnrollmentList from './components/EnrollmentList';
import './App.css';

function CoursesPage({ enrolledCourses, setEnrolledCourses }) {
  const handleEnroll = (course) => {
    setEnrolledCourses(prev => {
      const existing = prev.find(c => c.id === course.id);
      if (existing) {
        return prev.map(c => 
          c.id === course.id 
            ? { ...c, count: c.count + 1 } 
            : c
        );
      } else {
        return [...prev, { ...course, count: 1 }];
      }
    });
  };

  const handleDrop = (courseId) => {
    setEnrolledCourses(prev => {
      const updated = prev.map(course => 
        course.id === courseId 
          ? { ...course, count: course.count - 1 }
          : course
      ).filter(course => course.count > 0);
      return updated;
    });
  };

  return (
    <div className="courses-page">
      <Header />
      <div className="content">
        <CourseCatalog onEnroll={handleEnroll} />
        <EnrollmentList 
          enrolledCourses={enrolledCourses} 
          onDrop={handleDrop} 
        />
      </div>
      <Footer />
    </div>
  );
}

export default CoursesPage;