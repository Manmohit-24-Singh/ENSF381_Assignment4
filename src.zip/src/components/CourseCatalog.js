import React from 'react';
import coursesData from '../data/courses';
import CourseItem from './CourseItem';

function CourseCatalog({ onEnroll }) {
  return (
    <div className="course-catalog">
      <h2>Available Courses</h2>
      <div className="courses-grid">
        {coursesData.map(course => (
          <CourseItem 
            key={course.id} 
            course={course} 
            onEnroll={onEnroll} 
          />
        ))}
      </div>
    </div>
  );
}

export default CourseCatalog;