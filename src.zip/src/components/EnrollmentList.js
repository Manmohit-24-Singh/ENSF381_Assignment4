import React from 'react';
import EnrolledCourse from './EnrolledCourse';

function EnrollmentList({ enrolledCourses, onDrop }) {
  const totalCredits = enrolledCourses.reduce(
    (sum, course) => sum + (course.creditHours || 3) * course.count, 0
  );

  return (
    <div className="enrollment-list">
      <h2>Your Enrollment List</h2>
      {enrolledCourses.length === 0 ? (
        <p>No courses enrolled yet.</p>
      ) : (
        <>
          {enrolledCourses.map(course => (
            <EnrolledCourse 
              key={course.id} 
              course={course} 
              onDrop={onDrop} 
            />
          ))}
          <div className="total-credits">
            <strong>Total Credit Hours: {totalCredits}</strong>
          </div>
        </>
      )}
    </div>
  );
}

export default EnrollmentList;